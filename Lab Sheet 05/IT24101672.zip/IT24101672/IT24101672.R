getwd()
setwd("C:\\Users\\it24101672\\Documents\\IT24101672")
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE, sep = "")

head(Delivery_Times)
str(Delivery_Times)

# 2. Histogram with nine class intervals
histogram <- hist(Delivery_Times$Delivery_Time_.minutes.,
                  breaks = seq(20, 70, length.out = 10),
                  right = FALSE,
                  main = "Histogram of Delivery Times",
                  xlab = "Delivery Time (minutes)",
                  col = "green",
                  border = "black")

# 3. Comment on shape and calculate skewness
install.packages("e1071")
library(e1071)
skew_val <- skewness(Delivery_Times$Delivery_Time_.minutes.)
cat("Skewness:", skew_val, "\n")

# Shape comment based on skewness
if(skew_val > 0.5) {
  cat("The distribution is right-skewed (positively skewed)\n")
} else if(skew_val < -0.5) {
  cat("The distribution is left-skewed (negatively skewed)\n")
} else {
  cat("The distribution is approximately symmetric\n")
}

# 4. Frequency distribution and polygons
breaks <- histogram$breaks
freq <- histogram$counts
mids <- histogram$mids

# Create classes for frequency distribution
classes <- c()
for(i in 1:(length(breaks)-1)){
  classes[i] <- paste0("[", breaks[i], ",", breaks[i+1], ")")
}

# Display frequency distribution
freq_dist <- data.frame(Classes = classes, Frequency = freq)
print("Frequency Distribution:")
print(freq_dist)

# Frequency polygon (on same plot as histogram)
dev.new() # Open new window for frequency polygon
plot(mids, freq, type = 'o', 
     main = "Frequency Polygon for Delivery Times", 
     xlab = "Delivery Time (minutes)", 
     ylab = "Frequency", 
     ylim = c(0, max(freq)),
     col = "blue",
     pch = 16)
grid()

# Cumulative frequency (Ogive)
cum.freq <- cumsum(freq)
new <- c(0, cum.freq[-length(cum.freq)]) # Start with 0

dev.new() # Open new window for ogive
plot(breaks, new, type = 'o', 
     main = "Cumulative Frequency Polygon (Ogive) for Delivery Times",
     xlab = "Delivery Time (minutes)", 
     ylab = "Cumulative Frequency", 
     ylim = c(0, max(cum.freq)),
     col = "red",
     pch = 16)
grid()

# Display cumulative frequency table
cum_table <- data.frame(Upper_Limit = breaks, Cumulative_Frequency = new)
print("Cumulative Frequency Table:")
print(cum_table)