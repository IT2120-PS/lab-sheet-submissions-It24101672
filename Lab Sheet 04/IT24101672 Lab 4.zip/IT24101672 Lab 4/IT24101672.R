setwd("C:\\Users\\it24101672\\Documents\\IT24101672 Lab 4")
getwd()
#1
branch_data<-read.table("C:\\Users\\it24101672\\Documents\\Exercise.txt",header = TRUE,sep=",")
head(branch_data)

#2
str(branch_data)
summary(branch_data$Branch.Sales_X1.Advertising_X2.Years_X3)
boxplot(branch_data$Sales_X1, main = "Boxplot of Sales", ylab = "Sales (X1)", col = "lightblue")
#3
summary_stats <- summary(branch_data$Advertising_X2)
iqr_advertising <- IQR(branch_data$Advertising_X2)
#4
cat("Five number summary for advertising:\n", summary_stats, "\n")
cat("Interquartile Range (IQR) for advertising:", iqr_advertising, "\n")
find_outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
#4
years_outliers <- find_outliers(branch_data$Years_X3)
cat("Outliers in years variable:\n")
print(years_outliers)

